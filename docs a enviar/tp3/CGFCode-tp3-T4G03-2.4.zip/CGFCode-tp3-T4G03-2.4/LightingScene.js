var degToRad = Math.PI / 180.0;

var BOARD_WIDTH = 6.0;
var BOARD_HEIGHT = 4.0;

var BOARD_A_DIVISIONS = 30;
var BOARD_B_DIVISIONS = 100;

function LightingScene() {
	CGFscene.call(this);
}

LightingScene.prototype = Object.create(CGFscene.prototype);
LightingScene.prototype.constructor = LightingScene;

LightingScene.prototype.init = function(application) {
	CGFscene.prototype.init.call(this, application);

	this.initCameras();

	this.initLights();

	this.gl.clearColor(0.0, 0.0, 0.0, 1.0);
	this.gl.clearDepth(100.0);
	this.gl.enable(this.gl.DEPTH_TEST);
	this.gl.enable(this.gl.CULL_FACE);
	this.gl.depthFunc(this.gl.LEQUAL);

	this.axis = new CGFaxis(this);

	// Scene elements
	this.prism = new MyPrism(this, 8, 20);
	this.cylinder = new MyCylinder(this, 8, 20);
	this.hemisphere = new MyLidHemisphere(this, 8, 20);
	this.sphere = new MySphere(this, 8, 20);
	this.lamp = new MyHemisphere(this, 8, 20, -1);

	// Materials
	this.materialDefault = new CGFappearance(this);

	//TP2
	// Scene elements
	this.table = new MyTable(this);
	this.wall = new Plane(this);
	this.floor = new MyQuad(this);
	
	this.boardA = new Plane(this, BOARD_A_DIVISIONS);
	this.boardB = new Plane(this, BOARD_B_DIVISIONS);

	// Materials
	this.materialDefault = new CGFappearance(this);
	
	this.materialA = new CGFappearance(this);
	this.materialA.setAmbient(0.3,0.3,0.3,1);
	this.materialA.setDiffuse(0.6,0.6,0.6,1);
	this.materialA.setSpecular(0,0.2,0.8,1);
	this.materialA.setShininess(120);

	this.materialB = new CGFappearance(this);
	this.materialB.setAmbient(0.3,0.3,0.3,1);
	this.materialB.setDiffuse(0.6,0.6,0.6,1);
	this.materialB.setSpecular(0.8,0.8,0.8,1);	
	this.materialB.setShininess(120);

	this.papelChao = new CGFappearance(this);
	this.papelChao.setAmbient(0.2,0.6,0.8,1);
	this.papelChao.setDiffuse(0.2,0.6,0.8,1);
	this.papelChao.setSpecular(0.7,0.7,0.7,1);
	this.papelChao.setShininess(50);

	this.papelParede = new CGFappearance(this);
	this.papelParede.setAmbient(0.7,0.6,0.3,1);
	this.papelParede.setDiffuse(0.7,0.6,0.2,1);
	this.papelParede.setSpecular(0.7,0.7,0.7,1);
	this.papelParede.setShininess(50);

	this.globo = new CGFappearance(this);
	this.globo.setAmbient(0,0,1,1);
	this.globo.setDiffuse(0,0,1,1);
	this.globo.setSpecular(0,0,1,1);
	this.globo.setShininess(150);

	this.laranja = new CGFappearance(this);
	this.laranja.setAmbient(1,1/2,0,1);
	this.laranja.setDiffuse(1,1/2,0,1);
	this.laranja.setSpecular(1,1/2,0,1);
	this.laranja.setShininess(50);
};

LightingScene.prototype.initCameras = function() {
	this.camera = new CGFcamera(0.4, 0.1, 500, vec3.fromValues(30, 30, 30), vec3.fromValues(0, 0, 0));
};

LightingScene.prototype.initLights = function() {
	this.setGlobalAmbientLight(0, 0 ,0, 1);
	
	// Positions for lights
	this.lights[0].setPosition(5, 5, 5, 1);
	this.lights[0].setVisible(true);
	
	this.lights[1].setPosition(-5, 5, 5, 1);
	this.lights[1].setVisible(true);

	this.lights[0].setAmbient(0, 0, 0, 1);
	this.lights[0].setDiffuse(1.0, 1.0, 1.0, 1.0);
	this.lights[0].setSpecular(1.0, 1.0, 1.0, 1.0);
	this.lights[0].enable();

	this.lights[1].setAmbient(0, 0, 0, 1);
	this.lights[1].setDiffuse(1.0, 1.0, 1.0, 1.0);
	this.lights[1].setSpecular(1.0, 1.0, 1.0, 1.0);
	this.lights[1].enable();
};

LightingScene.prototype.updateLights = function() {
	for (i = 0; i < this.lights.length; i++)
		this.lights[i].update();
}

LightingScene.prototype.display = function() {
	// ---- BEGIN Background, camera and axis setup

	// Clear image and depth buffer everytime we update the scene
	this.gl.viewport(0, 0, this.gl.canvas.width, this.gl.canvas.height);
	this.gl.clear(this.gl.COLOR_BUFFER_BIT | this.gl.DEPTH_BUFFER_BIT);

	// Initialize Model-View matrix as identity (no transformation)
	this.updateProjectionMatrix();
	this.loadIdentity();

	// Apply transformations corresponding to the camera position relative to the origin
	this.applyViewMatrix();

	// Update all lights used
	this.updateLights();

	// Draw axis
	this.axis.display();

	this.materialDefault.apply();

	// ---- END Background, camera and axis setup


	// ---- BEGIN Primitive drawing section
	/*
	//Lamp
	this.pushMatrix();
		this.translate(5, 7.5, 5);
		this.rotate(Math.PI/2,1,0,0);
		this.lamp.display();
	this.popMatrix();

	//Lamp 2
	this.pushMatrix();
		this.translate(12, 7.5, 12);
		this.rotate(Math.PI/2,1,0,0);
		this.lamp.display();
	this.popMatrix();

	// Sphere (globe)
	this.pushMatrix();
		this.translate(5,4.3,8);
		this.rotate(-Math.PI/2,1,0,0);
		this.scale(1/2,1/2,1/2);
		this.globo.apply();
		this.sphere.display();
	this.popMatrix();

	// Hemisphere
	this.pushMatrix();
		this.translate(1,0,1);
		this.scale(1,5,1);
		this.rotate(-Math.PI/2,1,0,0);
		this.laranja.apply();
		this.hemisphere.display();
	this.popMatrix();

	// Cylinder
	this.pushMatrix();
		this.translate(11,3.8,8);
		this.rotate(-Math.PI/2,1,0,0);
		this.materialB.apply();
		this.cylinder.display();
	this.popMatrix();

	// Prism
	this.pushMatrix();
		this.translate(13,3.8,8);
		this.rotate(-Math.PI/2,1,0,0);
		this.materialB.apply();
		this.prism.display();
	this.popMatrix();

	//TP2
	// Floor
	this.pushMatrix();
		this.translate(7.5, 0, 7.5);
		this.rotate(-90 * degToRad, 1, 0, 0);
		this.scale(15, 15, 0.2);
		this.papelChao.apply();
		this.floor.display();
	this.popMatrix();

	// Left Wall
	this.pushMatrix();
		this.translate(0, 4, 7.5);
		this.rotate(90 * degToRad, 0, 1, 0);
		this.scale(15, 8, 0.2);
		this.papelParede.apply();
		this.wall.display();
	this.popMatrix();

	// Plane Wall
	this.pushMatrix();
		this.translate(7.5, 4, 0);
		this.scale(15, 8, 0.2);
		this.papelParede.apply();
		this.wall.display();
	this.popMatrix();

	// First Table
	this.pushMatrix();
		this.translate(5, 0, 8);
		this.table.display();
	this.popMatrix();

	// Second Table
	this.pushMatrix();
		this.translate(12, 0, 8);
		this.table.display();
	this.popMatrix();

	// Board A
	this.pushMatrix();
		this.translate(4, 4.5, 0.2);
		this.scale(BOARD_WIDTH, BOARD_HEIGHT, 1);
		
		this.materialA.apply();
		this.boardA.display();
	this.popMatrix();

	// Board B
	this.pushMatrix();
		this.translate(10.5, 4.5, 0.2);
		this.scale(BOARD_WIDTH, BOARD_HEIGHT, 1);
		
		this.materialB.apply();
		this.boardB.display();
	this.popMatrix();
	*/

	this.pushMatrix();
		this.translate(3,0,0);
		this.cylinder.display();
	this.popMatrix();

	this.prism.display();

	// ---- END Primitive drawing section
};
